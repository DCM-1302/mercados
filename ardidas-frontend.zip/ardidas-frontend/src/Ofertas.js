import React from 'react';
import { Header } from './Header';

function Ofertas() {
    return (
      <>
       <Header />    
       </>
    );
  }
  
  export {Ofertas};
  