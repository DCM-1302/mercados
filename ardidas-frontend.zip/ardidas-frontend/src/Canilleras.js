import React from 'react';
import { Header } from './Header';

function Canilleras() {
    return (
      <>
       <Header />    
       </>
    );
  }
  
  export {Canilleras};
  