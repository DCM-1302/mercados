import React from 'react';
import { Header } from './Header';

function Camisetas() {
    return (
      <>
       <Header />    
       </>
    );
  }
  
  export {Camisetas};
  