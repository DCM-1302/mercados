import React from 'react';
import { Header } from './Header';

function Guayos() {
    return (
      <>
       <Header />    
       </>
    );
  }
  
  export {Guayos};
  